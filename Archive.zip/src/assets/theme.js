import { createTheme } from "@mui/material";

const theme = createTheme({
  overrides: {},
});

export default theme;
